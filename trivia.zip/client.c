//Name: Sahil Virani
//Pledge: I pledge my honor that I have abided by the Stevens Honor System.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <errno.h>
#include <getopt.h>

#define SERVER_PORT 25555  // Default server port
#define BUFLEN 2048        // Buffer length for messages
#define MIN_PORT 1024      // Minimum valid port number
#define MAX_PORT 65535     // Maximum valid port number

// Function to print usage information
void print_usage(char *program_name) {
    printf("Usage: %s [-i IP_address] [-p port_number] [-h]\n", program_name);
    printf("  -i IP_address: Specify the server IP address. Default is \"127.0.0.1\"\n");
    printf("  -p port_number: Specify the server port number. Default is %d\n", SERVER_PORT);
    printf("  -h: Display this help info.\n");
}

// Function to handle incoming messages from the server
void process_server_message(int sock) {
    char buffer[BUFLEN];
    int len = recv(sock, buffer, BUFLEN - 1, 0);
    if (len > 0) {
        buffer[len] = '\0'; // Null-terminate the received data
        printf("%s\n", buffer); // Print the message from the server
    } else if (len == 0) {
        printf("Server closed the connection.\n");
        exit(0); // Exit if the server has closed the connection
    } else {
        perror("recv failed"); // Print the error if recv() failed
        exit(1);
    }
}

int main(int argc, char *argv[]) {
    const char *server_ip = "127.0.0.1"; // Default IP address of the server
    int port = SERVER_PORT; // Default server port
    int opt;

    // Parse command line arguments
    while ((opt = getopt(argc, argv, "i:p:h")) != -1) {
        switch (opt) {
            case 'i':
                server_ip = optarg; // Set server IP from command line
                break;
            case 'p':
                port = atoi(optarg); // Set server port from command line
                if (port < MIN_PORT || port > MAX_PORT) {
                    fprintf(stderr, "Error: Port must be in the range [%d, %d].\n", MIN_PORT, MAX_PORT);
                    return EXIT_FAILURE;
                }
                break;
            case 'h':
                print_usage(argv[0]); // Display help information
                return EXIT_SUCCESS;
            default:
                print_usage(argv[0]); // Display help information on error
                return EXIT_FAILURE;
        }
    }

    int sock;
    struct sockaddr_in server_addr;

    // Create a socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket creation failed");
        return 1;
    }

    // Set server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);
    server_addr.sin_addr.s_addr = inet_addr(server_ip);

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        return 1;
    }

    printf("Connected to the server at %s:%d\n", server_ip, port);

    fd_set readfds;
    struct timeval tv;

    // Main loop to handle input from server and user
    while (1) {
        FD_ZERO(&readfds);
        FD_SET(sock, &readfds);
        FD_SET(STDIN_FILENO, &readfds);

        tv.tv_sec = 2;  // Timeout for select
        tv.tv_usec = 0;

        int activity = select(sock + 1, &readfds, NULL, NULL, &tv);

        if (activity < 0 && errno != EINTR) {
            perror("select error");
            break;
        }

        // Check if there is incoming data from the server
        if (FD_ISSET(sock, &readfds)) {
            process_server_message(sock);
        }

        // Check if there is user input from the standard input
        if (FD_ISSET(STDIN_FILENO, &readfds)) {
            char input[BUFLEN];
            if (fgets(input, sizeof(input), stdin)) {
                input[strcspn(input, "\n")] = '\0'; // Remove newline character
                send(sock, input, strlen(input), 0); // Send input to the server
            }
        }
    }

    close(sock);
    return 0;
}
