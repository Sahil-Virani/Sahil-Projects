//Name: Sahil Virani
//Pledge: I pledge my honor that I have abided by the Stevens Honor System.

#define _POSIX_C_SOURCE 2
#define _GNU_SOURCE
#define MAX_ENTRIES 50
#define BUFLEN 2048
#define MAX_CLIENTS 3
#define DEFAULT_FILE "questions.txt"
#define DEFAULT_PORT 25555
#define DEFAULT_IP "127.0.0.1"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <ctype.h>
#include <stdbool.h>


typedef struct {
    int fd;
    int score;
    char name[128];
} Player;

typedef struct {
    char prompt[1024];
    char options[3][50];
    int answer_idx;
} Enter;

void showWin(Player *players, int clientCount) {
    int highestScore = -1;
    int validWinner = -1;
    char message[BUFLEN];

    // Iterate through players to find the one with the highest score
    for (int i = 0; i < clientCount; i++) {
        if (players[i].fd != 0 && players[i].score > highestScore) {
            highestScore = players[i].score;
            validWinner = i;
        }
    }

    // Prepare the message based on game results
    if (validWinner != -1) {
        // If there is a winner
        snprintf(message, sizeof(message), "Congrats, %s!", players[validWinner].name);
    } else {
        // If no winner could be determined
        snprintf(message, sizeof(message), "No winner this game.");
    }

    // Send the result message to all active players
    for (int i = 0; i < clientCount; i++) {
        if (players[i].fd != 0) {
            if (send(players[i].fd, message, strlen(message), 0) < 0) {
                perror("Failed to send winner message");
            }
        }
    }
}

void broadcastToAllPlayers(Player *players, const char *message) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (players[i].fd != 0) {
            if (send(players[i].fd, message, strlen(message), 0) < 0) {
                perror("Failed to send message to player");
            }
        }
    }
}

void handleClientResponse(int client_fd, Player *players, int playerIndex, Enter *questions, int questionIndex) {
    char buffer[BUFLEN];
    int bytes_received = recv(client_fd, buffer, sizeof(buffer) - 1, 0);
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0';
        int answer_index = atoi(buffer) - 1;

        char feedbackMsg[BUFLEN];
        if (answer_index == questions[questionIndex].answer_idx) {
            players[playerIndex].score++;
            snprintf(feedbackMsg, sizeof(feedbackMsg), "Correct answer from %s! The answer was: %s\n",
                     players[playerIndex].name, questions[questionIndex].options[questions[questionIndex].answer_idx]);
        } else {
            players[playerIndex].score--;
            snprintf(feedbackMsg, sizeof(feedbackMsg), "Incorrect answer from %s. The correct answer was: %s\n",
                     players[playerIndex].name, questions[questionIndex].options[questions[questionIndex].answer_idx]);
        }

        broadcastToAllPlayers(players, feedbackMsg);
    } else if (bytes_received == 0) {
        printf("Player %s disconnected.\n", players[playerIndex].name);
        close(client_fd);
        players[playerIndex].fd = 0;
    } else {
        perror("recv failed");
    }
}

void gameStart(Player *players, Enter *questions) {
    char buffer[BUFLEN];
    fd_set readfds;
    int max_fd = 0;

    for (int i = 0; i < MAX_ENTRIES; i++) {
        if (strlen(questions[i].prompt) == 0 ||
            strlen(questions[i].options[0]) == 0 ||
            strlen(questions[i].options[1]) == 0 ||
            strlen(questions[i].options[2]) == 0) {
            continue;
        }

        snprintf(buffer, sizeof(buffer), "Question %d: %s\nPress 1: %s, Press 2: %s, Press 3: %s\n",
                 i + 1, questions[i].prompt, questions[i].options[0], questions[i].options[1], questions[i].options[2]);

        broadcastToAllPlayers(players, buffer);

        FD_ZERO(&readfds);
        max_fd = 0;
        for (int j = 0; j < MAX_CLIENTS; j++) {
            if (players[j].fd > 0) {
                FD_SET(players[j].fd, &readfds);
                if (players[j].fd > max_fd) {
                    max_fd = players[j].fd;  // Directly comparing to find the max fd
                }
            }
        }

        int activity = select(max_fd + 1, &readfds, NULL, NULL, NULL);
        if (activity < 0) {
            perror("Select failed");
            continue;
        }

        for (int j = 0; j < MAX_CLIENTS; j++) {
            if (players[j].fd > 0 && FD_ISSET(players[j].fd, &readfds)) {
                handleClientResponse(players[j].fd, players, j, questions, i);
            }
        }
    }
    printf("End of game\n");
}

int readSingleLine(FILE *stream, char *outputBuffer, size_t bufferSize) {
    if (fgets(outputBuffer, bufferSize, stream) == NULL) {
        return 0; // Indicates failure or end of file
    }
    outputBuffer[strcspn(outputBuffer, "\n")] = 0; // Remove newline character
    return 1; // Indicates successful read
}

void parseOptionsFromLine(char *optionsLine, char parsedOptions[][50]) {
    sscanf(optionsLine, "%49s %49s %49s", parsedOptions[0], parsedOptions[1], parsedOptions[2]);
}

int findCorrectAnswerIndex(char *correctAnswer, char availableOptions[][50]) {
    for (int i = 0; i < 3; i++) {
        if (strcmp(availableOptions[i], correctAnswer) == 0) {
            return i; // Returns the index of the correct answer
        }
    }
    return -1; // Answer not found
}

int read_questions(Enter *questionEntries, const char *filePath) {
    FILE *inputFile = fopen(filePath, "r");
    if (!inputFile) {
        perror("Failed to open file");
        return -1;
    }

    int questionsLoaded = 0;
    char inputLine[1024];
    while (questionsLoaded < MAX_ENTRIES - 1) {
        if (!readSingleLine(inputFile, inputLine, sizeof(inputLine)) || strlen(inputLine) == 1) {
            break;  // Exit if unable to read a line or line is empty
        }

        strncpy(questionEntries[questionsLoaded].prompt, inputLine, sizeof(questionEntries[questionsLoaded].prompt));
        questionEntries[questionsLoaded].prompt[sizeof(questionEntries[questionsLoaded].prompt) - 1] = '\0'; // Ensure null termination

        if (!readSingleLine(inputFile, inputLine, sizeof(inputLine))) {
            break; // Exit if unable to read options
        }
        parseOptionsFromLine(inputLine, questionEntries[questionsLoaded].options);

        if (!readSingleLine(inputFile, inputLine, sizeof(inputLine))) {
            break; // Exit if unable to read the correct answer
        }

        int correctIndex = findCorrectAnswerIndex(inputLine, questionEntries[questionsLoaded].options);
        if (correctIndex == -1) {
            fprintf(stderr, "Error: Correct answer '%s' not found among options for question %d\n", inputLine, questionsLoaded + 1);
        } else {
            questionEntries[questionsLoaded].answer_idx = correctIndex;
        }

        fgets(inputLine, sizeof(inputLine), inputFile); // To skip any blank line after the answer
        questionsLoaded++;
    }

    fclose(inputFile);
    return questionsLoaded;
}

void initializePlayers(Player players[]) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        players[i].fd = 0;
        players[i].score = 0;
    }
}

void sendWelcomeMessage(int socket, char *playerName) {
    const char *welcomeMsg = "Welcome to 392 Trivia!\nPlease type your name: ";
    send(socket, welcomeMsg, strlen(welcomeMsg), 0);
    
    char buffer[BUFLEN];
    int bytesRead = recv(socket, buffer, sizeof(buffer), 0);
    if (bytesRead > 0) {
        buffer[bytesRead] = '\0'; // Ensures null termination
        strcpy(playerName, buffer); // Save player name

        char greetingMsg[BUFLEN];
        snprintf(greetingMsg, sizeof(greetingMsg), "Hi %s!", playerName);
        send(socket, greetingMsg, strlen(greetingMsg), 0);
    } else {
        perror("recv failed or client disconnected");
        close(socket);  // Close socket if receive fails
    }
}

int addNewPlayer(int serverSocket, Player players[], struct sockaddr_in *clientAddr) {
    socklen_t addrLen = sizeof(struct sockaddr_in);
    int clientSocket = accept(serverSocket, (struct sockaddr *)clientAddr, &addrLen);
    if (clientSocket < 0) {
        perror("accept");
        return -1;  // Return -1 on failure to accept a new connection
    }

    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (players[i].fd == 0) {
            players[i].fd = clientSocket;
            printf("New connection: socket fd %d, IP %s, Port %d\n",
                   clientSocket, inet_ntoa(clientAddr->sin_addr), ntohs(clientAddr->sin_port));

            sendWelcomeMessage(clientSocket, players[i].name);
            return i;  // Return player index on successful addition
        }
    }
    close(clientSocket); // No free slot found, close the newly accepted connection
    return -1;
}


int areAllPlayersConnected(Player players[]) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (players[i].fd == 0) {
            return 0; // If any player has fd 0, not all players are connected
        }
    }
    return 1; // All players are connected
}

void letInPlayer(int serverSocket, Player players[]) {
    struct sockaddr_in clientAddress;  // Declare the clientAddress here
    printf(" Waiting for connections ...\n");
    initializePlayers(players);

    while (1) {
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(serverSocket, &readfds);
        int maxSocketDesc = serverSocket;

        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (players[i].fd > 0) {
                FD_SET(players[i].fd, &readfds);
                if (players[i].fd > maxSocketDesc) {
                    maxSocketDesc = players[i].fd;
                }
            }
        }

        int activity = select(maxSocketDesc + 1, &readfds, NULL, NULL, NULL);
        if ((activity < 0) && (errno != EINTR)) {
            perror("Select error");
            continue;
        }

        if (FD_ISSET(serverSocket, &readfds)) {
            if (addNewPlayer(serverSocket, players, &clientAddress) < 0) {
                continue;  // Handle failed connection or full server
            }
        }

        if (areAllPlayersConnected(players)) {
            break; // Exit loop if all players are connected
        }
    }
}

int main(int argc, char *argv[]) {
    // Command-line argument parsing
    const char *filename = DEFAULT_FILE;
    const char *ip = DEFAULT_IP;
    unsigned short port = DEFAULT_PORT;
    int opt;

    while ((opt = getopt(argc, argv, "f:i:p:h")) != -1) {
        switch (opt) {
            case 'f':
                filename = optarg;
                break;
            case 'i':
                ip = optarg;
                break;
            case 'p':
                port = (unsigned short)atoi(optarg);
                break;
            case 'h':
                printf("Usage: %s [-f question_file] [-i IP_address] [-p port_number] [-h]\n"
                       " -f question_file      Default to 'questions.txt';\n"
                       " -i IP_address         Default to '127.0.0.1';\n"
                       " -p port_number        Default to 25555;\n"
                       " -h                    Display this help info.\n", argv[0]);
                exit(EXIT_SUCCESS);
            default:
                fprintf(stderr, "Error: Unknown option '-%c' received.\n", optopt);
                exit(EXIT_FAILURE);
        }
    }

    // Server setup
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("ERROR opening socket");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(ip);
    serv_addr.sin_port = htons(port);

    if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("ERROR on binding");
        exit(EXIT_FAILURE);
    }

    if (listen(sockfd, MAX_CLIENTS) < 0) {
        perror("ERROR on listen");
        exit(EXIT_FAILURE);
    }

    // Welcome message
    printf("Welcome to 392 Trivia!");

    // Load questions
    Enter entries[MAX_ENTRIES];
    int numEntries = read_questions(entries, filename);
    if (numEntries < 0) {
        fprintf(stderr, "Failed to load questions from the file.\n");
        exit(EXIT_FAILURE);
    }

    // Player setup and game initiation
    Player players[MAX_CLIENTS];
    letInPlayer(sockfd, players);
    gameStart(players, entries);

    // Display the winner and clean up
    showWin(players, MAX_CLIENTS);
    return 0;
}
